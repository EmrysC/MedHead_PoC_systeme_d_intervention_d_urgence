package MeadHead.MedHead_PoC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedHeadPoCSystemeDInterventionDUrgenceApplicationTests {

	@Test
	void contextLoads() {
	}

}
